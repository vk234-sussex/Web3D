namespace NetworkAbstractions.Models
{
    public struct ServerVersion
    {
        public int version;
    }
}