namespace NetworkAbstractions
{
    public enum RequestType
    {
        GET,
        HEAD,
        PUT,
        DELETE
    }
}